const { Client, GatewayIntentBits, REST, Routes, SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");
const { createClient } = require("@supabase/supabase-js");
const express = require("express");

const { DISCORD_TOKEN, DISCORD_CLIENT_ID, DISCORD_GUILD_ID, SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY } = process.env;
if (!DISCORD_TOKEN || !DISCORD_CLIENT_ID || !SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
  console.error("Missing env vars: DISCORD_TOKEN, DISCORD_CLIENT_ID, SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY");
  process.exit(1);
}
const db = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, { auth: { persistSession: false } });

const app = express();
app.get("/", (_req, res) => res.status(200).send("Karma bot is alive."));
app.get("/health", (_req, res) => res.status(200).json({ status: "ok" }));
app.listen(process.env.PORT || 10000, "0.0.0.0", () => console.log("Health endpoint started"));

// Replace with the exact gender role names in your server.
const GENDER_ROLES = { male: "Male", female: "Female", nonbinary: "Non-binary" };
const RANK_ROLES = ["Aam aadmi party", "Devta", "Devi", "Acha bacha", "Acha bachi", "Acha none of the above", "Nalayak", "Gaddar"];

async function rowsFor(targetId) {
  const { data, error } = await db.from("votes").select("*").eq("target_id", targetId);
  if (error) throw error;
  return data || [];
}
async function scoreFor(targetId) {
  return (await rowsFor(targetId)).filter(v => !v.undone).reduce((n, v) => n + v.value, 0);
}
function genderFor(member) {
  const m = member.roles.cache.some(r => r.name === GENDER_ROLES.male);
  const f = member.roles.cache.some(r => r.name === GENDER_ROLES.female);
  const nb = member.roles.cache.some(r => r.name === GENDER_ROLES.nonbinary);
  if ([m, f, nb].filter(Boolean).length !== 1) return null;
  return m ? "male" : f ? "female" : "nonbinary";
}
function rankFor(score, gender) {
  if (score <= -25) return "Gaddar";
  if (score <= -10) return "Nalayak";
  if (score < 0) return "Aam aadmi party";
  if (score >= 10) return gender === "male" ? "Acha bacha" : gender === "female" ? "Acha bachi" : gender === "nonbinary" ? "Acha none of the above" : "Aam aadmi party";
  return gender === "male" ? "Devta" : gender === "female" ? "Devi" : "Aam aadmi party";
}
async function updateRank(member) {
  if (!member || !member.manageable) return;
  const desired = rankFor(await scoreFor(member.id), genderFor(member));
  const role = member.guild.roles.cache.find(r => r.name === desired);
  if (!role) { console.warn(`Missing rank role: ${desired}`); return; }
  if (!member.guild.members.me || role.position >= member.guild.members.me.roles.highest.position) {
    console.warn(`Move the bot role above ${desired}`); return;
  }
  const rankIds = new Set(member.guild.roles.cache.filter(r => RANK_ROLES.includes(r.name)).map(r => r.id));
  const remove = member.roles.cache.filter(r => rankIds.has(r.id) && r.id !== role.id);
  if (remove.size) await member.roles.remove(remove).catch(console.error);
  if (!member.roles.cache.has(role.id)) await member.roles.add(role).catch(console.error);
}

const commands = [
  new SlashCommandBuilder().setName("rate").setDescription("Rate a user +1 or -1")
    .addUserOption(o => o.setName("user").setDescription("User to rate").setRequired(true))
    .addIntegerOption(o => o.setName("value").setDescription("+1 or -1").setRequired(true).addChoices({name:"+1",value:1},{name:"-1",value:-1}))
    .addStringOption(o => o.setName("reason").setDescription("Optional reason")),
  new SlashCommandBuilder().setName("score").setDescription("Show a user's score").addUserOption(o => o.setName("user").setDescription("User").setRequired(true)),
  new SlashCommandBuilder().setName("leaderboard").setDescription("Show the top scores"),
  new SlashCommandBuilder().setName("history").setDescription("Show recent ratings").addUserOption(o => o.setName("user").setDescription("User").setRequired(true)),
  new SlashCommandBuilder().setName("undo").setDescription("Undo latest active rating (Manage Server)")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addUserOption(o => o.setName("user").setDescription("User").setRequired(true))
].map(c => c.toJSON());

// Diagnostic test: use only Guilds to check whether GuildMembers is being rejected.
const client = new Client({ intents: [GatewayIntentBits.Guilds] });
client.once("ready", async () => {
  console.log(`Logged in as ${client.user.tag}`);
  const rest = new REST({ version: "10" }).setToken(DISCORD_TOKEN);
  try {
    if (DISCORD_GUILD_ID) await rest.put(Routes.applicationGuildCommands(DISCORD_CLIENT_ID, DISCORD_GUILD_ID), { body: commands });
    else await rest.put(Routes.applicationCommands(DISCORD_CLIENT_ID), { body: commands });
    for (const guild of client.guilds.cache.values()) {
      await guild.members.fetch().catch(console.error);
      for (const m of guild.members.cache.values()) if (!m.user.bot) await updateRank(m).catch(console.error);
    }
  } catch (e) { console.error("Startup setup error:", e); }
});
client.on("guildMemberUpdate", async (_old, member) => updateRank(member).catch(console.error));

client.on("interactionCreate", async i => {
  if (!i.isChatInputCommand()) return;
  try {
    if (i.commandName === "rate") {
      const user = i.options.getUser("user", true), value = i.options.getInteger("value", true);
      const reason = i.options.getString("reason") || "No reason provided";
      if (user.id === i.user.id) return i.reply({ content: "You cannot rate yourself.", ephemeral: true });
      if (user.bot) return i.reply({ content: "Bots cannot be rated.", ephemeral: true });
      const cutoff = new Date(Date.now() - 86400000).toISOString();
      const { data: recent, error: e1 } = await db.from("votes").select("id").eq("voter_id", i.user.id).eq("target_id", user.id).eq("undone", false).gt("created_at", cutoff).limit(1);
      if (e1) throw e1;
      if (recent?.length) return i.reply({ content: "You already rated this user in the last 24 hours.", ephemeral: true });
      const vote = { id: `${Date.now()}-${Math.random().toString(36).slice(2,9)}`, voter_id: i.user.id, voter_tag: i.user.tag, target_id: user.id, target_tag: user.tag, value, reason, created_at: new Date().toISOString(), undone: false, guild_id: i.guildId };
      const { error } = await db.from("votes").insert(vote);
      if (error) throw error;
      const member = i.guild ? await i.guild.members.fetch(user.id).catch(() => null) : null;
      if (member) await updateRank(member);
      return i.reply(`${user} received **${value > 0 ? "+1" : "-1"}**. Reason: ${reason}\nCurrent score: **${await scoreFor(user.id)}**`);
    }
    if (i.commandName === "score") {
      const user = i.options.getUser("user", true);
      return i.reply(`${user}'s score is **${await scoreFor(user.id)}**.`);
    }
    if (i.commandName === "leaderboard") {
      const { data, error } = await db.from("votes").select("target_id,value").eq("undone", false);
      if (error) throw error;
      const scores = new Map();
      for (const v of data || []) scores.set(v.target_id, (scores.get(v.target_id) || 0) + v.value);
      const top = [...scores].sort((a,b) => b[1]-a[1]).slice(0,10);
      if (!top.length) return i.reply("No ratings yet.");
      const lines = await Promise.all(top.map(async ([id,score],n) => {
        const u = await client.users.fetch(id).catch(() => null);
        return `**${n+1}.** ${u ? u.tag : `<@${id}>`} — **${score}**`;
      }));
      return i.reply(`**Karma leaderboard**\n${lines.join("\n")}`);
    }
    if (i.commandName === "history") {
      const user = i.options.getUser("user", true);
      const { data, error } = await db.from("votes").select("*").eq("target_id", user.id).order("created_at", {ascending:false}).limit(10);
      if (error) throw error;
      if (!data?.length) return i.reply(`No rating history for ${user}.`);
      return i.reply(`**Recent history for ${user}**\n${data.map(v => `${v.undone ? "~~UNDONE~~ " : ""}${v.value > 0 ? "+1" : "-1"} by <@${v.voter_id}> — ${v.reason} (${new Date(v.created_at).toLocaleString("en-IN",{timeZone:"Asia/Kolkata"})})`).join("\n")}`);
    }
    if (i.commandName === "undo") {
      if (!i.memberPermissions?.has(PermissionFlagsBits.ManageGuild)) return i.reply({content:"You need Manage Server permission.",ephemeral:true});
      const user = i.options.getUser("user", true);
      const { data, error } = await db.from("votes").select("*").eq("target_id",user.id).eq("undone",false).order("created_at",{ascending:false}).limit(1);
      if (error) throw error;
      if (!data?.length) return i.reply({content:`No active rating to undo for ${user}.`,ephemeral:true});
      const { error: e2 } = await db.from("votes").update({undone:true,undone_at:new Date().toISOString(),undone_by:i.user.id}).eq("id",data[0].id);
      if (e2) throw e2;
      const member = i.guild ? await i.guild.members.fetch(user.id).catch(() => null) : null;
      if (member) await updateRank(member);
      return i.reply(`Undid the latest active rating for ${user}. New score: **${await scoreFor(user.id)}**.`);
    }
  } catch (e) {
    console.error(e);
    const msg = {content:"Something went wrong. Check Render logs for details.",ephemeral:true};
    if (i.replied || i.deferred) await i.followUp(msg).catch(()=>{}); else await i.reply(msg).catch(()=>{});
  }
});
client.login(DISCORD_TOKEN);
